export const environment = {
  production: true,
  apiUrl: 'https://domain.com/api/'
};
