# TodoApp
Quartz.Net + SignalR
FE: Angular
BE: .Net Core 5
demo: https://youtu.be/wo10N3AQfRM
