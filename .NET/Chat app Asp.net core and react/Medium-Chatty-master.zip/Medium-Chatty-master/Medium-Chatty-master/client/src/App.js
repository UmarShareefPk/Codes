import React from 'react';
import Chat from './Chat/Chat';

function App() {
  return (
    <div style={{ margin: '0 30%' }}>
      <Chat />
    </div>
  );
}

export default App;
