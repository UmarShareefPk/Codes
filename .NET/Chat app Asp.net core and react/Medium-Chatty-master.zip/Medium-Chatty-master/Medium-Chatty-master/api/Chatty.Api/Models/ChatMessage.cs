namespace Chatty.Api.Models
{
    public class ChatMessage
    {
        public string User { get; set; }

        public string Message { get; set; }
    }
}