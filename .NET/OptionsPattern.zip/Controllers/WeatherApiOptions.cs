﻿using System.ComponentModel.DataAnnotations;

namespace OptionsPattern.Controllers
{
    public class WeatherApiOptions
    {
        public const string WeatherApi = "WeatherApi";
        
        [Required]
        public string Url { get; set; }
        [Required]
        public string Key { get; set; }
        [Range(10, 100)]
        public int Count { get; set; }
    }
}