﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace OptionsPattern.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private readonly ILogger<WeatherForecastController> _logger;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IConfiguration _configuration;
        private WeatherApiOptions _weatherOptions;

        public WeatherForecastController(
        ILogger<WeatherForecastController> logger, 
        IHttpClientFactory httpClientFactory,
        IConfiguration configuration,
        IOptionsSnapshot<WeatherApiOptions> weatherOptions)
        {
            _logger = logger;
            _httpClientFactory = httpClientFactory;
            _configuration = configuration;
            _weatherOptions = weatherOptions.Value;
        }

        [HttpGet]
        public async Task<string> Get(string cityName = "Brisbane")
        {
            string baseUrl = _weatherOptions.Url;
            string key = _weatherOptions.Key;
            
            string url = $"{baseUrl}?key={key}&q={cityName}";
            using (var client = _httpClientFactory.CreateClient())
            {
                return await client.GetStringAsync(url);
            }
        }
    }
}
