﻿using log4net;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Log4netSample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitializeLogging();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
          
             LogInfo("Test", "123");
            try
            {
                int b = 0;
                int i = 1 / b;
            }
            catch(Exception ex)
            {
                LogException(ex, "error");
            }
        }

        private static void InitializeLogging()
        {
            try
            {
                var logFile = AppDomain.CurrentDomain.BaseDirectory + "Logger.config";
                if (System.IO.File.Exists(logFile))
                    log4net.Config.XmlConfigurator.ConfigureAndWatch(new System.IO.FileInfo(logFile));
               // Console.Clear();
            }
            catch (System.IO.IOException Io)
            {

            }
            catch (Exception ex)
            {
                //Utils.LogException(ex, "InitializeLogging");
                Console.WriteLine(ex.Message);
            }
        }

        public static void LogException(Exception ex, string className)
        {
            ILog log = LogManager.GetLogger(className);

            log.Info("****************** Exception Block ******************");
            log.Error("Exception Message: " + ex.Message);
            log.Error("Inner Exception: " + ex.InnerException);
            log.Error("Exception Object: " + ex);
            log.Info("***************** End Exception Block ****************");

        }

        public static void LogInfo(string info, string className)
        {
            ILog log = LogManager.GetLogger(className);

            log.Info(info);
        }


    } // end of class
}
